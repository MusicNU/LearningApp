# animation with annotation

A Pen created on CodePen.io. Original URL: [https://codepen.io/bcd/pen/ayVXvY](https://codepen.io/bcd/pen/ayVXvY).

